package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.text.StyledEditorKit.BoldAction;

import dto.User;


public class LoginConditionDAO {
	
	public int checklogin(String txtUserID,String txtPassword) {
		DBConnect connectDB = new DBConnect();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = connectDB.getConnection();
			String sql = "SELECT COUNT(*) AS CNT FROM MSTUSER WHERE USERID=? AND PASSWORD=?";
			System.out.println(sql);
			
			ps = conn.prepareStatement(sql);
			ps.setString(1, txtUserID);
			ps.setString(2, txtPassword);
			rs = ps.executeQuery();
			rs.next();
			int cnt = rs.getInt("CNT");
			System.out.println(cnt);
			if(cnt == 1) {
				return 1;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 2;
	}
	public static void main(String[] args) {
		LoginConditionDAO lo = new LoginConditionDAO();
		int a = lo.checklogin("116", "2323");
				System.out.println(a);
	}
}
