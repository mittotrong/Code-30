package form;

import javax.servlet.http.HttpServletRequest;

import logic.LoginLogic;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.taglib.html.ErrorsTag;

public class LoginForm extends ActionForm {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String txtUserID;
	private String txtPassword;
	private String txtUsername;
	private String btnClear;
	private String btnLogin;
	private static final String FAILURE = "failure";
	
	public LoginForm() {
		
	}


	public String getTxtUserID() {
		return txtUserID;
	}


	public void setTxtUserID(String txtUserID) {
		this.txtUserID = txtUserID;
	}


	public String getTxtPassword() {
		return txtPassword;
	}


	public void setTxtPassword(String txtPassword) {
		this.txtPassword = txtPassword;
	}


	public String getTxtUsername() {
		return txtUsername;
	}


	public void setTxtUsername(String txtUsername) {
		this.txtUsername = txtUsername;
	}
	
	public String getBtnClear() {
		return btnClear;
	}


	public void setBtnClear(String btnClear) {
		this.btnClear = btnClear;
	}


	public String getBtnLogin() {
		return btnLogin;
	}


	public void setBtnLogin(String btnLogin) {
		this.btnLogin = btnLogin;
	}
	/*public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
			ActionErrors errors = new ActionErrors();
			if(this.txtUserID.length() == 0){
				errors.add("errors", new ActionMessage("userid.not.entered"));
				
			} else if (this.txtPassword.length() == 0) {
				errors.add("errors",new ActionMessage("password.not.entered"));
			} else if (mapping.getForward() != null) {
				errors.add("errors", new ActionMessage("login.error"));
			}
			
			return errors;
	}*/
	public void reset(ActionMapping mapping, HttpServletRequest request)
	  {
	    super.reset(mapping,request);
	    txtUserID = "";
	    txtPassword = "";
	  }

}
