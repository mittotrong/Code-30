package action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import dao.CustomerDAO;
import dto.Customer;
import form.CustomerForm;

public class CustomerAction extends Action {
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		CustomerForm customerform = (CustomerForm) form;
		
		CustomerDAO dao = new CustomerDAO();
		
		ArrayList<Customer> listcustomer = dao.getAllCustomer();
		
		ArrayList<Customer> list15 = new ArrayList<Customer>();
		
		int page = customerform.getPage();
		
		if(page == 0){
			page = 1;
		}
		int maxpage = listcustomer.size() / 15;
		
		if(listcustomer.size()%15 != 0){maxpage++;}
		
		// xu ly disable
		if(page > maxpage) {page = 1;}
		
		
		
		int start = (page - 1) *15 + 1;
		int end = start +14;
		if(end >listcustomer.size()){
			end = listcustomer.size();
		}
		for(int i=start;i<=end;i++){
			list15.add(listcustomer.get(i-1));
		}
		
		Customer listdone = new Customer();
		listdone.setList(list15);
		listdone.setPagenumber(maxpage);
		listdone.setPage(page);
		
		list15.add(listdone);
		
		request.setAttribute("list15", list15);
		request.setAttribute("maxpage", maxpage );
		/*request.setAttribute("start",index);
		request.setAttribute("all", dao.countCustomers());*/
		return mapping.findForward("list");
	}
}
