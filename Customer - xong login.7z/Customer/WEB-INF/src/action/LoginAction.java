package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import logic.LoginLogic;

import org.apache.struts.action.Action;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import dao.LoginConditionDAO;
import dao.LoginDAO;
import dto.User;
import form.LoginForm;

public class LoginAction extends Action {
	// STATIC VALUE
	private static final String SUCCESS = "success";
	private static final String FAILURE = "failure";

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {

		// Cast LoginActionForm
		LoginForm loginform = (LoginForm) form;
		// Declare Struts Session
		HttpSession session = request.getSession();
				
		// DTO - User - Username
		User user = new User();

		// Getting userid and password from the user
		String txtUserID = loginform.getTxtUserID();
		String txtPassword = loginform.getTxtPassword();
		
		// Declare Action Message
		ActionMessages errors = new ActionMessages();

		// Conditional - Button CLEAR
		if ("Clear".equals(loginform.getBtnClear())) {
			System.out.println(loginform.getBtnClear());
			loginform.reset(mapping, request);
		}
		
		// Conditional - Button LOGIN
		if ("Login".equals(loginform.getBtnLogin())) {
			// REMOVE TESTCASE
			System.out.println(txtUserID);
			System.out.println(txtPassword);
			System.out.println(loginform.getBtnLogin());

			// if user not enter - userid
			if (loginform.getTxtUserID() == ""
					|| loginform.getTxtPassword() == null) {
				errors.add("lblErrorMessage", new ActionMessage("userid.not.entered"));

				// if user not enter - password
			} else if (loginform.getTxtPassword() == null
					|| loginform.getTxtPassword() == "") {
				errors.add("lblErrorMessage", new ActionMessage("password.not.entered"));

				// user input done - check CNT # 1 - login error
			} else {
				// Declare login logic
				LoginLogic logic = new LoginLogic();
				if (logic.loginLogic(txtUserID, txtPassword) != 1) {
					errors.add("lblErrorMessage", new ActionMessage("login.error"));
				}
			}
			
			// save errors action
			saveErrors(request, errors);
			// return username and mapping success - if errors is empty
			if (errors.isEmpty()) {
				// Declare loginlogic
				LoginLogic logic = new LoginLogic();
				// Calling methid getusernameLogic()
				user = logic.getusernameLogic(txtUserID, txtPassword);
				// Set attribute
				session.setAttribute("TxtUsername", user.getTxtUsername());
				return mapping.findForward(SUCCESS);

			}
		}
		return mapping.findForward(FAILURE);
	}

}
