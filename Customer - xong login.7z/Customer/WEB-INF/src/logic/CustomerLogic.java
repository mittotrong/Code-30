package logic;

import java.util.ArrayList;

import dto.Customer;

public class CustomerLogic {
	/*CustomerDAOTest dao = new  CustomerDAOTest();*/

/*	public ListCustomer getListCustomer(){*/
		/*ListCustomer listCustomer = new ListCustomer();
		ArrayList<Customer> list1 = dao.getListCustomer();*/
		/*ArrayList<Customer> list2 = new ArrayList<Customer>();*/
		
/*		int maxpage = list1.size() /15;
		if(list1.size() % 15 != 0){maxpage++;}
		if(page > maxpage) {page = 1;}
		int start = (page - 1) *15 + 1;
		int end = start +14;
		if(end >list1.size()){
			end = list1.size();
		}
		for(int i=start;i<=end;i++){
			list2.add(list1.get(i-1));
		}*/
		
		
	}
