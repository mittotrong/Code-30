package dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnect {
	private static Connection conn = null;

	public Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/customersystem";
			conn = DriverManager.getConnection(url, "root", "");
			System.out.println("connect");
			return conn;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("connect" + e);
		}
		return null;
	}
}
