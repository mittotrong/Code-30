package form;

import javax.servlet.http.HttpServletRequest;

import logic.LoginLogic;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

public class CustomerForm extends ActionForm {

	private int llblCustomerID;
	private String lblCustomerName;
	private String lblSex;	
	private String lblBirthday;
	private String lblAddress;
	private int page;
	private int pagenumber;
	
	
	public int getLlblCustomerID() {
		return llblCustomerID;
	}
	public void setLlblCustomerID(int llblCustomerID) {
		this.llblCustomerID = llblCustomerID;
	}
	public String getLblCustomerName() {
		return lblCustomerName;
	}
	public void setLblCustomerName(String lblCustomerName) {
		this.lblCustomerName = lblCustomerName;
	}
	public String getLblSex() {
		return lblSex;
	}
	public void setLblSex(String lblSex) {
		this.lblSex = lblSex;
	}
	public String getLblBirthday() {
		return lblBirthday;
	}
	public void setLblBirthday(String lblBirthday) {
		this.lblBirthday = lblBirthday;
	}
	public String getLblAddress() {
		return lblAddress;
	}
	public void setLblAddress(String lblAddress) {
		this.lblAddress = lblAddress;
	}

	public int getPagenumber() {
		return pagenumber;
	}
	public void setPagenumber(int pagenumber) {
		this.pagenumber = pagenumber;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
/*	public ActionErrors validate(ActionMapping mapping,
			HttpServletRequest request) {
		// Declare LoginLogic - Call LoginLogic method
		LoginLogic logic = new LoginLogic();
		
		if (txtUserID.length() == 0 && txtPassword.length() != 0) {
			errors.add("lblErrorMessage", new ActionMessage(
					"userid.not.entered"));
		} else if (txtPassword.length() == 0 && txtUserID.length() != 0) {
			errors.add("lblErrorMessage", new ActionMessage(
					"password.not.entered"));
		} else if (logic.loginLogic(txtUserID, txtPassword) == 2) {
			
			errors.add("lblErrorMessage", new ActionMessage(
					"login.error"));
		} 
		return errors;
	}*/

}
