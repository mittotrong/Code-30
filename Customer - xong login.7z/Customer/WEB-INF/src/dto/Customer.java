package dto;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts.action.ActionForm;

public class Customer extends ActionForm {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int llblCustomerID;
	private String lblCustomerName;
	private String lblSex;
	private String lblBirthday;
	private String lblAddress;
	private int page;
	private int pagenumber;
	private List<Customer> list;

	public Customer() {

	}

	public Customer(int llblCustomerID, String lblCustomerName, String lblSex,
			String lblBirthday, String lblAddress, int page,
			int pagenumber, ArrayList<Customer> list) {
		super();
		this.llblCustomerID = llblCustomerID;
		this.lblCustomerName = lblCustomerName;
		this.lblSex = lblSex;
		this.lblBirthday = lblBirthday;
		this.lblAddress = lblAddress;
		this.page = page;
		this.pagenumber = pagenumber;
		this.list = list;
	}

	public int getLlblCustomerID() {
		return llblCustomerID;
	}

	public void setLlblCustomerID(int llblCustomerID) {
		this.llblCustomerID = llblCustomerID;
	}

	public String getLblCustomerName() {
		return lblCustomerName;
	}

	public void setLblCustomerName(String lblCustomerName) {
		this.lblCustomerName = lblCustomerName;
	}

	public String getLblSex() {
		return lblSex;
	}

	public void setLblSex(String lblSex) {
		this.lblSex = lblSex;
	}

	public String getLblBirthday() {
		return lblBirthday;
	}

	public void setLblBirthday(String lblBirthday) {
		this.lblBirthday = lblBirthday;
	}

	public String getLblAddress() {
		return lblAddress;
	}

	public void setLblAddress(String lblAddress) {
		this.lblAddress = lblAddress;
	}

	public int getPagenumber() {
		return pagenumber;
	}

	public void setPagenumber(int pagenumber) {
		this.pagenumber = pagenumber;
	}

	public List<Customer> getList() {
		return list;
	}

	public void setList(List<Customer> list) {
		this.list = list;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}


}
