package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import dto.User;


public class LoginDAO {
	
	public User getusername(String txtUserID, String txtPassword) {
		DBConnect connectDB = new DBConnect();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = connectDB.getConnection();
			String sql = "SELECT USERNAME FROM MSTUSER WHERE USERID=? AND PASSWORD=?";
			System.out.println(sql);
			
			ps = conn.prepareStatement(sql);
			ps.setString(1, txtUserID);
			ps.setString(2, txtPassword);
			rs = ps.executeQuery();
			if (rs.next()) {
				User user = new User();
				user.setTxtUsername(rs.getString(1));
				return user;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
