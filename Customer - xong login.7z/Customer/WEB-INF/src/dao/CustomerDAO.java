package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.jsp.tagext.TryCatchFinally;

import dto.Customer;

import form.CustomerForm;

public class CustomerDAO {

	DBConnect connectDB = new DBConnect();
	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	//private final int LIMIT = 15;
	public ArrayList<Customer> getAllCustomer(){
		conn = connectDB.getConnection();
		/*String sql = "SELECT * FROM ( SELECT *, ROW_NUMBER() OVER (ORDER BY CUSTOMER_ID) as row FROM MSTCUSTOMER ) a WHERE row > ? and row <= ?";*/
		/*String sql = "SELECT * FROM ( SELECT *, ROW_NUMBER() OVER (ORDER BY CUSTOMER_ID) as row FROM MSTCUSTOMER ) a WHERE CUSTOMER_ID IS NOT NULL";*/
 		String sql = "SELECT * FROM MSTCUSTOMER ORDER BY CUSTOMER_ID";
		ArrayList<Customer> customerlist = new ArrayList<Customer>();
		try {
			ps = conn.prepareStatement(sql);
			
			/*int start = index * LIMIT;
			ps.setInt(1, start);
			
			int end = start + LIMIT;
			ps.setInt(2, end);*/
			
			rs = ps.executeQuery();
			while (rs.next()) {
				
				Customer cus = new Customer();
				cus.setLlblCustomerID(rs.getInt("CUSTOMER_ID"));
				cus.setLblCustomerName(rs.getString("CUSTOMER_NAME"));
				cus.setLblSex(rs.getString("SEX"));
				cus.setLblBirthday(rs.getString("BIRTHDAY"));
				cus.setLblAddress(rs.getString("ADDRESS"));
				customerlist.add(cus);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return customerlist;
		
	}
	public int countCustomers() throws SQLException {
		int count = 0;
		Statement sm;
		ResultSet rs;
		sm = connectDB.getConnection().createStatement();
		String sql = "SELECT Count(CUSTOMER_ID) FROM MSTCUSTOMER";
		rs = sm.executeQuery(sql);
		while (rs.next()) {
			count = rs.getInt(1);
		}
		return count;
	}
}
