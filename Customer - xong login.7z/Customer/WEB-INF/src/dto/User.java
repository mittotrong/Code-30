package dto;

public class User {
	private String txtUsername;
	private String txtUserID;
	private String txtPassword;

	public User() {
	}
	

	


	public User(String txtUsername, String txtUserID, String txtPassword,
			int cnt) {
		super();
		this.txtUsername = txtUsername;
		this.txtUserID = txtUserID;
		this.txtPassword = txtPassword;
	}




	public String getTxtUsername() {
		return txtUsername;
	}



	public void setTxtUsername(String txtUsername) {
		this.txtUsername = txtUsername;
	}



	public String getTxtUserID() {
		return txtUserID;
	}



	public void setTxtUserID(String txtUserID) {
		this.txtUserID = txtUserID;
	}



	public String getTxtPassword() {
		return txtPassword;
	}



	public void setTxtPassword(String txtPassword) {
		this.txtPassword = txtPassword;
	}
	

}
