package logic;

import dao.LoginConditionDAO;
import dao.LoginDAO;
import dto.User;

public class LoginLogic {
	public User getusernameLogic(String txtUserID, String txtPassword){
		// Declare method class
		LoginDAO dao = new LoginDAO();
		return dao.getusername(txtUserID, txtPassword);
	}
	public int loginLogic(String txtUserID, String txtPassword){
		// Declare method class
		LoginConditionDAO cntdao = new LoginConditionDAO();
		if(cntdao.checklogin(txtUserID, txtPassword) == 1){
		return 1 ;
	}
		return 2; 	
	}		
}
